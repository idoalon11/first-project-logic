﻿using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Ex02
{
    internal class Step
    {
        private Point m_Start;
        private Point m_End;
        private bool m_IsEatStep;

        public Step()
        {
            m_IsEatStep = false;
        }

        public bool IsEatStep
        {
            get
            {
                return m_IsEatStep;
            }

            set
            {
                m_IsEatStep = value;
            }
        }

        public Point Start
        {
            get
            {
                return m_Start;
            }

            set
            {
                m_Start = value;
            }
        }

        public Point End
        {
            get
            {
                return m_End;
            }

            set
            {
                m_End = value;
            }
        }

        internal static bool IsValidFormat(string i_userInput)
        {
            bool isValidFormat = true;

            if (i_userInput.Length != 5)
            {
                isValidFormat = false;
            }
            else if (!char.IsUpper(i_userInput[0]) || !char.IsUpper(i_userInput[3]))
            {
                isValidFormat = false;
            }
            else if (!char.IsLower(i_userInput[1]) || !char.IsLower(i_userInput[4]))
            {
                isValidFormat = false;
            }
            else if (!i_userInput[2].Equals('>'))
            {
                isValidFormat = false;
            }

            return isValidFormat;
        }

        internal static int CharToInt(char i_CharToConvert)
        {
            return (int)(i_CharToConvert - 97);
        }

        internal static bool IsValid(Step i_CurrentStep, string i_UserInput, List<Step> i_ListOfSteps)
        {
            bool isValid = true;
            Point startPoint, endPoint;

            if (IsValidFormat(i_UserInput))
            {
                startPoint = new Point(CharToInt(i_UserInput[1]), CharToInt(char.ToLower(i_UserInput[0])));
                endPoint = new Point(CharToInt(i_UserInput[4]), CharToInt(char.ToLower(i_UserInput[3])));
                i_CurrentStep.SetStep(startPoint, endPoint);

                if (!i_CurrentStep.IsStepInList(i_ListOfSteps))
                {
                    isValid = false;
                }
            }
            else
            {
                isValid = false;
            }

            return isValid;
        }

        internal bool IsStepInList(List<Step> i_ListOfSteps)
        {
            bool isStepInList = false;

            foreach (Step step in i_ListOfSteps)
            {
                if (m_Start == step.Start && m_End == step.End)
                {
                    isStepInList = true;
                }
            }

            return isStepInList;
        }

        internal void SetStep(Point i_Start, Point i_End)
        {
            m_Start.Y = i_Start.Y;
            m_Start.X = i_Start.X;
            m_End.Y = i_End.Y;
            m_End.X = i_End.X;
        }

        internal string StepToString()
        {
            StringBuilder stepToString = new StringBuilder();
            stepToString.Append((char)(m_Start.Y + 65));
            stepToString.Append((char)(m_Start.X + 97));
            stepToString.Append(">");
            stepToString.Append((char)(m_End.Y + 65));
            stepToString.Append((char)(m_End.X + 97));
            return stepToString.ToString();
        }
    }
}
