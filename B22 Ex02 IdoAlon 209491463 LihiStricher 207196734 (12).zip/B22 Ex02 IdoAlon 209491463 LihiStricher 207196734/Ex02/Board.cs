﻿using System.Drawing;
using System.Text;

namespace Ex02
{
    internal class Board
    {
        private readonly int r_Size;
        private Coin[,] m_GameBoard;

        public Board(int i_Size)
        {
            r_Size = i_Size;
            m_GameBoard = new Coin[r_Size, r_Size];
        }

        public int Size
        {
            get
            {
                return r_Size;
            }
        }

        public Coin[,] GameBoard
        {
            get
            {
                return m_GameBoard;
            }

            set
            {
                m_GameBoard = value;
            }
        }

        public static bool IsValidSize(int i_Size)
        {
            bool isValid = false;

            if (i_Size == 6 || i_Size == 8 || i_Size == 10)
            {
                isValid = true;
            }

            return isValid;
        }

        internal void Init(Player i_FirstPlayer, Player i_SecondPlayer)
        {
            i_FirstPlayer.MyCoins.Clear();
            i_SecondPlayer.MyCoins.Clear();
            for (int i = 0; i < r_Size; i++)
            {
                for (int j = 0; j < r_Size; j++)
                {
                    m_GameBoard[i, j] = new Coin(' ', new Point(i, j));
                }
            }

            for (int i = 0; i < (r_Size / 2) - 1; i++)
            {
                rowInit(i, (i + 1) % 2, (char)Coin.eCharOfCoins.SecondPlayer,  i_SecondPlayer);
            }

            for (int i = (r_Size / 2) + 1; i < r_Size; i++)
            {
                rowInit(i, (i + 1) % 2, (char)Coin.eCharOfCoins.FirstPlayer,  i_FirstPlayer);
            }

            PrintBoard();
        }

        private void rowInit(int i_NumberOfRow, int i_NumberOFStartCol, char i_PlayerCoin,  Player i_Player)
        {
            Point currentPoint;
            Coin currentCoin;

            for (int j = i_NumberOFStartCol; j < r_Size; j = j + 2)
            {
                currentPoint = new Point(i_NumberOfRow, j);
                currentCoin = new Coin(i_PlayerCoin, currentPoint);
                m_GameBoard[i_NumberOfRow, j] = currentCoin;
                i_Player.AddToCoinList(currentCoin);
            }
        }

        internal void SetBoard(Step i_CurrentStep)
        {
            int startX = i_CurrentStep.Start.X;
            int startY = i_CurrentStep.Start.Y;
            int endX = i_CurrentStep.End.X;
            int endY = i_CurrentStep.End.Y;

            m_GameBoard[endX, endY] = m_GameBoard[startX, startY];
            m_GameBoard[endX, endY].PlaceOnBoard = i_CurrentStep.End;
            m_GameBoard[startX, startY] = new Coin(' ', new Point(startX, startY));

            if (i_CurrentStep.IsEatStep)
            {
                m_GameBoard[(startX + endX) / 2, (startY + endY) / 2] = new Coin(' ', new Point((startX + endX) / 2, (startY + endY) / 2));
            }

            NeedToMakeKing(i_CurrentStep.End);
            PrintBoard();
        }

        internal void PrintBoard()
        {
            StringBuilder board = new StringBuilder();

            Ex02.ConsoleUtils.Screen.Clear();
            for (int i = 0; i <= r_Size; i++)
            {
                for (int j = 0; j < r_Size; j++)
                {
                    if (i == 0)
                    {
                        board.Append("   " + (char)(j + 65));
                    }
                    else
                    {
                        if (j == 0)
                        {
                            board.Append((char)(i + 96) + "|");
                        }

                        if(m_GameBoard[i - 1, j] != null)
                        {
                            board.Append(" " + m_GameBoard[i - 1, j].CharOfCoin + " |");
                        }
                        else
                        {
                            board.Append("   |");
                        }
                    }
                }

                board.AppendLine();
                board.Append(" ");
                board.Append('=', (4 * r_Size) + 1);
                board.AppendLine();
            }

            System.Console.Write(board.ToString());
        }

        internal void NeedToMakeKing(Point i_PlaceOnBoard)
        {
            if (i_PlaceOnBoard.X == 0 && !m_GameBoard[i_PlaceOnBoard.X, i_PlaceOnBoard.Y].IsKing())
            {
                m_GameBoard[i_PlaceOnBoard.X, i_PlaceOnBoard.Y].CharOfCoin = (char)Coin.eCharOfCoins.FirstPlayerKing;
            }
            else if (i_PlaceOnBoard.X == r_Size - 1 && !m_GameBoard[i_PlaceOnBoard.X, i_PlaceOnBoard.Y].IsKing())
            {
                m_GameBoard[i_PlaceOnBoard.X, i_PlaceOnBoard.Y].CharOfCoin = (char)Coin.eCharOfCoins.SecondPlayerKing;
            }
        }
    }
}
