﻿using System;

namespace Ex02
{
    internal class Progam
    {
        public static void Main()
        {
            start();
        }

        private static void start()
        {
            bool userInput;
            string firstPlayerName;
            string secondPlayerName;
            int sizeOfBoard;
            int numberOfPlayers;
            bool againstComputer = false;

            Console.WriteLine("Please enter your name ");
            firstPlayerName = Console.ReadLine();
            while (!Player.IsValidName(firstPlayerName))
            {
                Console.WriteLine("Your name is invalid. Please enter your name again:");
                firstPlayerName = Console.ReadLine();
            }

            Console.WriteLine("Please enter the size of the board 6, 8 or 10");
            userInput = int.TryParse(Console.ReadLine(), out sizeOfBoard);

            while (!userInput || !Board.IsValidSize(sizeOfBoard))
            {
                Console.WriteLine("Your input is invalid");
                Console.WriteLine("Please enter the size of the board 6, 8 or 10");
                userInput = int.TryParse(Console.ReadLine(), out sizeOfBoard);
            }

            Console.WriteLine("If you want to play against the computer please enter 0, otherwise please enter 1");
            userInput = int.TryParse(Console.ReadLine(), out numberOfPlayers);
            while (!userInput || !isZeroOrOne(numberOfPlayers))
            {
                Console.WriteLine("Your input is invalid");
                Console.WriteLine("If you want to play against the computer please enter 0, otherwise please enter 1");
                userInput = int.TryParse(Console.ReadLine(), out numberOfPlayers);
            }

            if (numberOfPlayers == 0)
            {
                againstComputer = true;
                secondPlayerName = "Computer";
            }
            else
            {
                Console.WriteLine("Please enter the second name ");
                secondPlayerName = Console.ReadLine();
                while (!Player.IsValidName(secondPlayerName))
                {
                    Console.WriteLine("Your name is invalid. Please enter second name again:");
                    secondPlayerName = Console.ReadLine();
                }
            }

            Game game = new Game(firstPlayerName, secondPlayerName, sizeOfBoard, againstComputer);

            while (game.UserWantToContinue)
            {
                int wantToContinue;

                game.Init();
                Console.WriteLine("If you want to play another round enter 1 , else press 0");
                userInput = int.TryParse(Console.ReadLine(), out wantToContinue);
                if (!userInput || !isZeroOrOne(wantToContinue))
                {
                    Console.WriteLine("Your numebr is invalid");
                    Console.WriteLine("If you want to play another round enter 1 , else press 0");
                    userInput = int.TryParse(Console.ReadLine(), out wantToContinue);
                }

                if (wantToContinue == 0)
                {
                    game.UserWantToContinue = false;
                }
            }
        }

        private static bool isZeroOrOne(int i_IntToCheck)
        {
            bool isZeroOrOne = false;

            if(i_IntToCheck == 0 || i_IntToCheck == 1)
            {
                isZeroOrOne = true;
            }

            return isZeroOrOne;
        }
    }
}
