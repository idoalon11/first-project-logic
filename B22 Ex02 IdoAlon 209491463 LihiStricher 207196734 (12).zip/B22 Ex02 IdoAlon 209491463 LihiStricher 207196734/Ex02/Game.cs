﻿using System;
using System.Collections.Generic;

namespace Ex02
{
    internal class Game
    {
        private readonly Board r_Board;
        private readonly Player r_FirstPlayer;
        private readonly Player r_SecondPlayer;
        private bool m_UserWantToContinue;
        private Player m_CurrentPlayer;
        private Player m_NextPlayer;
        private List<Step> m_ListOfRegularStep;
        private List<Step> m_ListOfEatStep;
        private Step m_CurrentStep;

        public Game(string i_FirstPlayerName, string i_SecondPlayerName, int i_SizeOfBoard, bool i_IsComputer)
        {
            r_FirstPlayer = new Player(i_FirstPlayerName, (int)Coin.eDirections.Up, false);
            r_SecondPlayer = new Player(i_SecondPlayerName, (int)Coin.eDirections.Down, i_IsComputer);
            r_Board = new Board(i_SizeOfBoard);
            m_ListOfRegularStep = new List<Step>();
            m_ListOfEatStep = new List<Step>();
            m_CurrentStep = new Step();
            m_UserWantToContinue = true;
        }

        public bool UserWantToContinue
        {
            get
            {
                return m_UserWantToContinue;
            }

            set
            {
                m_UserWantToContinue = value;
            }
        }

        internal void Init()
        {
            r_Board.Init(r_FirstPlayer, r_SecondPlayer);
            startNewGame();
        }

        private void startNewGame()
        {
            bool userWantToQuit = false;

            m_CurrentPlayer = r_FirstPlayer;
            m_NextPlayer = r_SecondPlayer;
            m_CurrentPlayer.UpdateLists(m_ListOfEatStep, m_ListOfRegularStep, r_Board);
            while (!isTheGameOver() && !userWantToQuit)
            {
                clearLists();
                m_CurrentPlayer.UpdateLists(m_ListOfEatStep, m_ListOfRegularStep, r_Board);
                if (m_CurrentPlayer.IsComputer)
                {
                    computerStep();
                }
                else
                {
                    playerStep(ref userWantToQuit);
                }
            }
        }

        private void playerStep(ref bool i_UserWantToQuit)
        {
            string userInput = null;

            m_CurrentStep.IsEatStep = false;
            Console.WriteLine(m_CurrentPlayer.Name + "'s turn " + "(" + currentPlayerChar() + ") :");
            userInput = Console.ReadLine();
            if (userInput.Equals("Q"))
            {
                i_UserWantToQuit = true;
            }
            else
            {
                while (m_ListOfEatStep.Count != 0)
                {
                    if (m_CurrentStep.IsEatStep)
                    {
                        Console.WriteLine("Nice move " + m_CurrentPlayer.Name + "! Keep going! \nEnter another eat step:");
                        userInput = Console.ReadLine();
                    }

                    m_CurrentStep.IsEatStep = true;
                    while (!Step.IsValid(m_CurrentStep, userInput, m_ListOfEatStep))
                    {
                        Console.WriteLine("Your input is invalid. Note that if you can eat, you must eat.. ");
                        userInput = Console.ReadLine();
                    }

                    m_NextPlayer.RemoveCoinFromList(r_Board.GameBoard[(m_CurrentStep.Start.X + m_CurrentStep.End.X) / 2, (m_CurrentStep.Start.Y + m_CurrentStep.End.Y) / 2]);
                    r_Board.SetBoard(m_CurrentStep);
                    clearLists();
                    r_Board.GameBoard[m_CurrentStep.End.X, m_CurrentStep.End.Y].AddToEatList(m_ListOfEatStep, m_CurrentPlayer.DirectionMove, r_Board);
                }

                if (!m_CurrentStep.IsEatStep)
                {
                    while (!Step.IsValid(m_CurrentStep, userInput, m_ListOfRegularStep))
                    {
                        Console.WriteLine("Your input is invalid.");
                        userInput = Console.ReadLine();
                    }

                    r_Board.SetBoard(m_CurrentStep);
                }

                Console.WriteLine(m_CurrentPlayer.Name + "'s move was " + "(" + currentPlayerChar() + "): " + userInput);
                switchPlayers();
                clearLists();
                m_CurrentPlayer.UpdateLists(m_ListOfEatStep, m_ListOfRegularStep, r_Board);
            }
        }

        private void computerStep()
        {
            int randomNumberToChooseStep;

            m_CurrentStep.IsEatStep = false;
            while (m_ListOfEatStep.Count != 0)
            {
                randomNumberToChooseStep = new Random().Next(0, m_ListOfEatStep.Count);
                m_CurrentStep = m_ListOfEatStep[randomNumberToChooseStep];
                m_CurrentStep.IsEatStep = true;
                m_NextPlayer.RemoveCoinFromList(r_Board.GameBoard[(m_CurrentStep.Start.X + m_CurrentStep.End.X) / 2, (m_CurrentStep.Start.Y + m_CurrentStep.End.Y) / 2]);
                r_Board.SetBoard(m_CurrentStep);
                clearLists();
                r_Board.GameBoard[m_CurrentStep.End.X, m_CurrentStep.End.Y].AddToEatList(m_ListOfEatStep, m_CurrentPlayer.DirectionMove, r_Board);
            }

            if (!m_CurrentStep.IsEatStep)
            {
                randomNumberToChooseStep = new Random().Next(0, m_ListOfRegularStep.Count);

                m_CurrentStep = m_ListOfRegularStep[randomNumberToChooseStep];
                r_Board.SetBoard(m_CurrentStep);
            }

            Console.WriteLine(m_CurrentPlayer.Name + "'s move was " + "(" + currentPlayerChar() + "): " + m_CurrentStep.StepToString());
            switchPlayers();
        }

        private void clearLists()
        {
            m_ListOfEatStep.Clear();
            m_ListOfRegularStep.Clear();
        }

        private char currentPlayerChar()
        {
            char currentPlayerChar;

            if (m_CurrentPlayer == r_FirstPlayer)
            {
                currentPlayerChar = (char)Coin.eCharOfCoins.FirstPlayer;
            }
            else
            {
                currentPlayerChar = (char)Coin.eCharOfCoins.SecondPlayer;
            }

            return currentPlayerChar;
        }

        private bool isTheGameOver()
        {
            bool gameOver = false;

            if (playerCantMove(r_FirstPlayer) && playerCantMove(r_SecondPlayer))
            {
                gameOver = true;
                Console.WriteLine("Its a draw!");
            }
            else if (checkWin())
            {
                gameOver = true;
                printScore();
            }

            return gameOver;
        }

        private bool playerCantMove(Player i_PlayerToCheck)
        {
            bool cantMove = false;

            clearLists();
            i_PlayerToCheck.UpdateLists(m_ListOfEatStep, m_ListOfRegularStep, r_Board);
            if (m_ListOfRegularStep.Count == 0 && m_ListOfEatStep.Count == 0)
            {
                cantMove = true;
            }

            clearLists();

            return cantMove;
        }

        private void printScore()
        {
            int loserScore = m_CurrentPlayer.CalculateScore();
            int winnerScore = m_NextPlayer.CalculateScore();

            m_NextPlayer.Score += Math.Abs(winnerScore - loserScore);
            Console.WriteLine("The winner is: " + m_NextPlayer.Name);
            Console.WriteLine(r_FirstPlayer.Name + "'s score is: " + r_FirstPlayer.Score);
            Console.WriteLine(r_SecondPlayer.Name + "'s score is: " + r_SecondPlayer.Score);
        }

        private bool checkWin()
        {
            bool thereIsWin = false;

            if (playerCantMove(m_CurrentPlayer) || runOutOfCoins(m_CurrentPlayer))
            {
                thereIsWin = true;
            }

            return thereIsWin;
        }

        private bool runOutOfCoins(Player i_CurretPlayer)
        {
            bool noMoreCoins = false;

            if (i_CurretPlayer.MyCoins.Count == 0)
            {
                noMoreCoins = true;
            }

            return noMoreCoins;
        }

        private void switchPlayers()
        {
            Player tempPlayer = null;
            tempPlayer = m_CurrentPlayer;
            m_CurrentPlayer = m_NextPlayer;
            m_NextPlayer = tempPlayer;
        }
    }
}
