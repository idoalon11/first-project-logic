﻿using System;
using System.Text;
using Ex01_02;

namespace Ex01_03
{
    public class Program
    {
        private static bool IsValidInput(string i_InputToCheck, ref int o_UserInput)
        {
            bool isValid = true;
            if (!int.TryParse(i_InputToCheck, out o_UserInput))
            {
                isValid = false;
            }
            else if (o_UserInput < 0)
            {
                isValid = false;
            }

            return isValid;
        }

        public static void Main()
        {
            Console.WriteLine("please enter the height for the sand clock");
            string userInputString = Console.ReadLine();
            int userInput = 0;
            while (!IsValidInput(userInputString, ref userInput))
            {
                Console.WriteLine("The input you entered is invalid. Please try again.");
                userInputString = Console.ReadLine();
            }

            StringBuilder sandClock = new StringBuilder();
            if (userInput % 2 == 0)
            {
                Console.WriteLine(Ex01_02.Program.SandClockForBeginners(sandClock, 0, userInput + 1));
            }
            else
            {
                Console.WriteLine(Ex01_02.Program.SandClockForBeginners(sandClock, 0, userInput));
            }
        }
    }
}
