﻿using System;
using System.Text;

namespace Ex01_04
{
    public class Program
    {
        private static bool IsPalindrome(string i_StringToCheack)
        {
            StringBuilder helperStringBuilderInReverse = new StringBuilder();
            StringBuilder reversString = ReverseBuilder(helperStringBuilderInReverse, i_StringToCheack, i_StringToCheack.Length - 1);

            return reversString.ToString().Equals(i_StringToCheack);
        }

        private static StringBuilder ReverseBuilder(StringBuilder io_reversString, string i_StringToReverse, int i_indexHelper)
        {
            if (i_indexHelper >= 0)
            {
                io_reversString.Append(i_StringToReverse[i_indexHelper]);
                ReverseBuilder(io_reversString, i_StringToReverse.Substring(0, i_StringToReverse.Length - 1), i_indexHelper - 1);
            }

            return io_reversString;
        }

        private static bool IsValidInput(string i_UserInput)
        {
            bool isValidInput = true;
            if (i_UserInput.Length != 8)
            {
                isValidInput = false;
            }
            else if (!ConsistOnlyLetters(i_UserInput))
            {
                isValidInput = false;
                if (ConsistOnlyNumbers(i_UserInput))
                {
                    isValidInput = true;
                }
            }

            return isValidInput;
        }

        private static bool DiviedByThree(string i_NumberToCheck)
        {
            return int.Parse(i_NumberToCheck) % 3 == 0;
        }

        private static int NumberOfLowerLetters(string i_StringToCheck)
        {
            int numberOfLowerLetters = 0;
            for (int i = 0; i < i_StringToCheck.Length; i++)
            {
                if (char.IsLower(i_StringToCheck, i))
                {
                    numberOfLowerLetters++;
                }
            }

            return numberOfLowerLetters;
        }

        private static bool ConsistOnlyLetters(string i_StringToCheck)
        {
            bool isConsistOnlyLetters = true;
            for (int i = 0; i < i_StringToCheck.Length; i++)
            {
                if (!char.IsLetter(i_StringToCheck, i))
                {
                    isConsistOnlyLetters = false;
                }
            }

            return isConsistOnlyLetters;
        }

        private static bool ConsistOnlyNumbers(string i_StringToCheck)
        {
            bool isConsistOnlyNumbers = true;
            for (int i = 0; i < i_StringToCheck.Length; i++)
            {
                if (!char.IsNumber(i_StringToCheck, i))
                {
                    isConsistOnlyNumbers = false;
                }
            }

            return isConsistOnlyNumbers;
        }

        public static void Main()
        {
            Console.WriteLine("Please enter a string consists of 8 characters");
            string userInput = Console.ReadLine();
            while(!IsValidInput(userInput))
            {
                Console.WriteLine("The input you entered is invalid. Please try again.");
                userInput = Console.ReadLine();
            }

            string outputMessage = null;
            if (ConsistOnlyNumbers(userInput))
            {
                outputMessage = string.Format("Is palindrome: {0} \nIs diveded by 3: {1}", IsPalindrome(userInput), DiviedByThree(userInput));
            }
            else
            {
                outputMessage = string.Format("Is palindrome: {0} \nThe number of the lowercase letters: {1}", IsPalindrome(userInput), NumberOfLowerLetters(userInput));
            }

            Console.WriteLine(outputMessage);
        }
    }
}
