﻿using System;

namespace Ex01_01
{
    public class Program
    {
        private const int k_NumberOfDigits = 8;

        private static bool IsBinary(string i_NumberToCheckIfBinary)
        {
            bool isBinary = true;
            for(int i = 0; i < k_NumberOfDigits; i++)
            {
                if (i_NumberToCheckIfBinary[i] != '0' && i_NumberToCheckIfBinary[i] != '1')
                {
                    isBinary = false;
                }
            }

            return isBinary;
        }

        private static bool IsValidInput(string i_NumberToCheck)
        {
            bool isValid = true;
            int userInpuut = 0;
            if (!int.TryParse(i_NumberToCheck, out userInpuut) || (i_NumberToCheck.Length != k_NumberOfDigits) || !IsBinary(i_NumberToCheck))
            {
                isValid = false;
            }

            return isValid;
        }

        private static int[] ConvertToDecimal(string[] i_InputsBinaryNumbersArray)
        {
            int[] inputsDecimalNumbersArray = new int[i_InputsBinaryNumbersArray.Length];
            for (int i = 0; i < i_InputsBinaryNumbersArray.Length; i++)
            {
                double newDecimalNumber = 0;
                for (int j = 0; j < i_InputsBinaryNumbersArray[i].Length; j++)
                {
                    string currentBinarySring = i_InputsBinaryNumbersArray[i];
                    int currentCharToConvert = currentBinarySring[k_NumberOfDigits - 1 - j] - '0';
                    newDecimalNumber += currentCharToConvert * Math.Pow(2.0, (double)j);
                }

                inputsDecimalNumbersArray[i] = (int)newDecimalNumber;
            }

            return inputsDecimalNumbersArray;
        }

        private static string ArrayToString(int[] i_InputsDecimalNumbersArray)
        {
            string[] stringFormatArguments = new string[i_InputsDecimalNumbersArray.Length];
            for (int i = 0; i < i_InputsDecimalNumbersArray.Length; i++)
            {
                stringFormatArguments[i] = i_InputsDecimalNumbersArray[i].ToString();
            }

            return string.Format("{0}, {1}, {2}", stringFormatArguments);
        }

        private static int StrictlyMonotonicallyIncreasingSequence(int[] i_InputsDecimalNumbersArray)
        {
            int numberOfStrictlyMonotonically = 0;
            for (int i = 0; i < i_InputsDecimalNumbersArray.Length; i++)
            {
                bool isStrictlyMonotonicallyIncreasingSequence = true;
                int numberToCheck = i_InputsDecimalNumbersArray[i];
                while (numberToCheck > 0)
                {
                    if (numberToCheck % 10 <= ((numberToCheck / 10) % 10))
                    {
                        isStrictlyMonotonicallyIncreasingSequence = false;
                    }

                    numberToCheck /= 10;
                }

                if (isStrictlyMonotonicallyIncreasingSequence)
                {
                    numberOfStrictlyMonotonically++;
                }
            }

            return numberOfStrictlyMonotonically;
        }

        private static int NumberOfOnes(string i_NumberToCheack)
        {
            int numberOfOnes = 0;
            for (int i = 0; i < i_NumberToCheack.Length; i++)
            {
                if (i_NumberToCheack[i] == '1')
                {
                    numberOfOnes++;
                }
            }

            return numberOfOnes;
        }

        private static int PowerOfTwo(string[] i_ArrayToCheackPowerOfTwo)
        {
            int numberOfDigitsThatArePowerOfTwo = 0;
            for (int i = 0; i < i_ArrayToCheackPowerOfTwo.Length; i++)
            {
                if (NumberOfOnes(i_ArrayToCheackPowerOfTwo[i]) == 1)
                {
                    numberOfDigitsThatArePowerOfTwo++;
                }
            }

            return numberOfDigitsThatArePowerOfTwo;
        }

        private static int IsPalindrome(int[] i_InputsDecimalNumbersArray)
        {
            int numberOfPalindromes = 0;
            for (int i = 0; i < i_InputsDecimalNumbersArray.Length; i++)
            {
                if (i_InputsDecimalNumbersArray[i] == ReverseNumber(i_InputsDecimalNumbersArray[i]))
                {
                    numberOfPalindromes++;
                }
            }

            return numberOfPalindromes;
        }

        private static int ReverseNumber(int i_NemberToReverse)
        {
            int reversedNumber = 0;
            while (i_NemberToReverse > 0)
            {
                reversedNumber = (reversedNumber * 10) + (i_NemberToReverse % 10);
                i_NemberToReverse /= 10;
            }

            return reversedNumber;
        }

        private static float AverageAmountOfDigit(int i_DigitToCheack, string[] i_ArrayToCheackAverage)
        {
            int numberOfInputs = i_ArrayToCheackAverage.Length;
            float sumOfTheCheckedDigit = 0;
            for (int i = 0; i < i_ArrayToCheackAverage.Length; i++)
            {
                if (i_DigitToCheack == 1)
                {
                    sumOfTheCheckedDigit += NumberOfOnes(i_ArrayToCheackAverage[i]);
                }
                else
                {
                    sumOfTheCheckedDigit += k_NumberOfDigits - NumberOfOnes(i_ArrayToCheackAverage[i]);
                }
            }

            return sumOfTheCheckedDigit / numberOfInputs;
        }

        private static int GreatestNumberInArray(int[] i_ArrayToCheackGreatest)
        {
            int greatesNumberInArray = i_ArrayToCheackGreatest[0];
            for (int i = 1; i < i_ArrayToCheackGreatest.Length; i++)
            {
                if (i_ArrayToCheackGreatest[i] > greatesNumberInArray)
                {
                    greatesNumberInArray = i_ArrayToCheackGreatest[i];
                }
            }

            return greatesNumberInArray;
        }

        private static int SmallestNumberInArray(int[] i_InputsDecimalNumbersArray)
        {
            int smallestNumberInArray = i_InputsDecimalNumbersArray[0];
            for (int i = 1; i < i_InputsDecimalNumbersArray.Length; i++)
            {
                if (i_InputsDecimalNumbersArray[i] < smallestNumberInArray)
                {
                    smallestNumberInArray = i_InputsDecimalNumbersArray[i];
                }
            }

            return smallestNumberInArray;
        }

        private static string NumbersToWords(int i_NumberToConvert)
        {
            string converedNumber = null;
            if (i_NumberToConvert == 0)
            {
                converedNumber = "zero";
            }
            else if (i_NumberToConvert == 1)
            {
                converedNumber = "one";
            }
            else if (i_NumberToConvert == 2)
            {
                converedNumber = "two";
            }
            else if (i_NumberToConvert == 3)
            {
                converedNumber = "three";
            }

            return converedNumber;
        }

        public static void Main()
        {
            string[] inputsBinaryNumbersArray = new string[3];
            Console.WriteLine("Please enter 3 numbers with 8 digit number each: ");
            for (int i = 0; i < inputsBinaryNumbersArray.Length; i++)
            {
                inputsBinaryNumbersArray[i] = Console.ReadLine();
                while (!IsValidInput(inputsBinaryNumbersArray[i]))
                {
                    Console.WriteLine("The input you entered is invalid. Please try again.");
                    inputsBinaryNumbersArray[i] = Console.ReadLine();
                }
            }

            int[] inputsDecimalNumbersArray = ConvertToDecimal(inputsBinaryNumbersArray);
            string[] stringFormatArguments = new string[8];
            stringFormatArguments[0] = ArrayToString(inputsDecimalNumbersArray);
            stringFormatArguments[1] = NumbersToWords(PowerOfTwo(inputsBinaryNumbersArray));
            stringFormatArguments[2] = NumbersToWords(StrictlyMonotonicallyIncreasingSequence(inputsDecimalNumbersArray));
            stringFormatArguments[3] = AverageAmountOfDigit(1, inputsBinaryNumbersArray).ToString();
            stringFormatArguments[4] = AverageAmountOfDigit(0, inputsBinaryNumbersArray).ToString();
            stringFormatArguments[5] = NumbersToWords(IsPalindrome(inputsDecimalNumbersArray));
            stringFormatArguments[6] = GreatestNumberInArray(inputsDecimalNumbersArray).ToString();
            stringFormatArguments[7] = SmallestNumberInArray(inputsDecimalNumbersArray).ToString();
            string outputMessage = string.Format(
                "The numbers are: {0} - {1} of them is power of 2," +
                " {2} of them consists digits whitch are a \"strictly monotonically increasing sequence\", " +
                "the average of ones is {3}, the average of zeros is {4}, {5} of them is palindrome, the greatest is {6}, smallest is {7}.", stringFormatArguments);
            Console.WriteLine(outputMessage);
        }
    }
}
