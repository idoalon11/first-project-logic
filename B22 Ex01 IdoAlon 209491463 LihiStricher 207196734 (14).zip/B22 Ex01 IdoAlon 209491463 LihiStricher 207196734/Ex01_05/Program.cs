﻿using System;

namespace Ex01_05
{
    public class Program
    {
        private static bool IsValidInput(string i_UserInput)
        {
            bool isValidInput = true;
            int userInput = 0;
            if (i_UserInput.Length != 7 || !int.TryParse(i_UserInput, out userInput))
            {
                isValidInput = false;
            }
            else if (userInput < 0)
            {
                isValidInput = false;
            }

            return isValidInput;
        }

        private static int CharToInt(char i_CharToConvert)
        {
            return (int)(i_CharToConvert - '0');
        }

        private static double AverageOfDigits(string i_NumberToCalculateAverage)
        {
            double sumOfDigits = 0.0;
            for (int i = 0; i < i_NumberToCalculateAverage.Length; i++)
            {
                sumOfDigits += char.GetNumericValue(i_NumberToCalculateAverage[i]);
            }

            return sumOfDigits / i_NumberToCalculateAverage.Length;
        }

        private static int SmallestDigitInInput(string i_NumberToCheckSmallestDigit)
        {
            int smallestDigitInInput = CharToInt(i_NumberToCheckSmallestDigit[0]);
            for (int i = 1; i < i_NumberToCheckSmallestDigit.Length; i++)
            {
                int currentDigit = CharToInt(i_NumberToCheckSmallestDigit[i]);
                if (currentDigit < smallestDigitInInput)
                {
                    smallestDigitInInput = currentDigit;
                }
            }

            return smallestDigitInInput;
        }

        private static int NumberOfEvenDigits(string i_NumberToCheckNumberOfEvenDigits)
        {
            int numberOfEvenDigits = 0;
            for (int i = 0; i < i_NumberToCheckNumberOfEvenDigits.Length; i++)
            {
                if (CharToInt(i_NumberToCheckNumberOfEvenDigits[i]) % 2 == 0)
                {
                    numberOfEvenDigits++;
                }
            }

            return numberOfEvenDigits;
        }

        private static int NumberOfDigitsSmallerThanTheUnitsDigit(string i_NumberToCheckDigitsSmallerThanTheUnitsDigit)
        {
            int indexOfUnitsDigit = i_NumberToCheckDigitsSmallerThanTheUnitsDigit.Length - 1;
            int unitsDigit = CharToInt(i_NumberToCheckDigitsSmallerThanTheUnitsDigit[indexOfUnitsDigit]);
            int digitsSmallerThanTheUnitsDigit = 0;
            for (int i = 0; i < i_NumberToCheckDigitsSmallerThanTheUnitsDigit.Length; i++)
            {
                if (CharToInt(i_NumberToCheckDigitsSmallerThanTheUnitsDigit[i]) < unitsDigit)
                {
                    digitsSmallerThanTheUnitsDigit++;
                }
            }

            return digitsSmallerThanTheUnitsDigit;
        }

        public static void Main()
        {
            Console.WriteLine("Please enter a number consists of 7 digit");
            string userInput = Console.ReadLine();
            while (!IsValidInput(userInput))
            {
                Console.WriteLine("The input you entered is invalid. Please try again.");
                userInput = Console.ReadLine();
            }

            string[] stringFormatArguments = new string[4];
            stringFormatArguments[0] = SmallestDigitInInput(userInput).ToString();
            stringFormatArguments[1] = AverageOfDigits(userInput).ToString();
            stringFormatArguments[2] = NumberOfEvenDigits(userInput).ToString();
            stringFormatArguments[3] = NumberOfDigitsSmallerThanTheUnitsDigit(userInput).ToString();
            string outputMessage = string.Format("The smallest digit is: {0}\nThe average of the digits is: {1}\n" + "The number of even numbers is: {2}\nThe number of digits are smaller than the units digit is: {3}", stringFormatArguments);
            Console.WriteLine(outputMessage);
        }
    }
}
