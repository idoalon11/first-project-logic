﻿using System;
using System.Text;

namespace Ex01_02
{
    public class Program
    {
        public static StringBuilder SandClockForBeginners(StringBuilder io_SandClock, int i_NumberOfLine, int i_HeightOfSandClock)
        {
            if (i_NumberOfLine == (i_HeightOfSandClock - 1))
            {
                io_SandClock.Append('*', i_HeightOfSandClock);
            }
            else if (i_NumberOfLine <= (i_HeightOfSandClock / 2))
            {
                io_SandClock.Append(' ', i_NumberOfLine);
                io_SandClock.Append('*', i_HeightOfSandClock - (i_NumberOfLine * 2));
                io_SandClock.Append(' ', i_NumberOfLine);
                io_SandClock.Append("\n");
                SandClockForBeginners(io_SandClock, i_NumberOfLine + 1, i_HeightOfSandClock);
            }
            else
            {
                io_SandClock.Append(' ', i_HeightOfSandClock - i_NumberOfLine - 1);
                io_SandClock.Append('*', (i_NumberOfLine * 2) - i_HeightOfSandClock + 2);
                io_SandClock.Append(' ', i_HeightOfSandClock - i_NumberOfLine - 1);
                io_SandClock.Append("\n");
                SandClockForBeginners(io_SandClock, i_NumberOfLine + 1, i_HeightOfSandClock);
            }

            return io_SandClock;
        }

        public static void Main()
        {
            StringBuilder sandClock = new StringBuilder();
            Console.WriteLine(SandClockForBeginners(sandClock, 0, 5));
        }
    }
}
