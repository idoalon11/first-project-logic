﻿namespace Ex03.GarageLogic
{
    internal class Electric : EnergySource
    {
    }
}
